print("First Sequence:")
for i in range(5, 18, 4):
    print(i)
print("Second Sequence:")
for i in range(26, 4, -7):
    print(i)